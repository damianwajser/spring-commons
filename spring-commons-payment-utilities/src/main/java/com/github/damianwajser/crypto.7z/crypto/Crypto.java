package com.github.damianwajser.crypto;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import com.github.damianwajser.crypto.impl.RSA;

public class Crypto  {

     private ICrypto icrypto = null;
    public Crypto(CryptoFormat cryptoFormat) throws NoSuchAlgorithmException {
        this.icrypto= CryptoFactory.getFormatter(cryptoFormat);
    }

 
    public String Encription(String key, String textPlain) throws NoSuchAlgorithmException {
               
        return icrypto.Encryption(key, textPlain);
    }

    public String Description(String key, String textPlain) throws NoSuchAlgorithmException {
      
        return icrypto.Encryption(key, textPlain);
    }

    public HashMap<String, String> Getkey() throws NoSuchAlgorithmException {
       
        return icrypto.Getkey();
    }
    public static void main(String[] args) throws IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException, BadPaddingException, NoSuchAlgorithmException {
    Crypto crypto = new Crypto(CryptoFormat.RSA);

    String encrypted=  crypto.Encription(crypto.Getkey().get("PublicKey"), "Hola mundo");
    String decripted=  crypto.Encription(crypto.Getkey().get("PrivateKey"), encrypted);
    System.out.println(encrypted);
    System.out.println(decripted);

    }
}
