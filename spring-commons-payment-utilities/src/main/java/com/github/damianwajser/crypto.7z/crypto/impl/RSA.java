package com.github.damianwajser.crypto.impl;



import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import com.github.damianwajser.crypto.ICrypto;

import java.math.BigInteger;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.HashMap;

public class RSA  implements ICrypto{

    //private static String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCgFGVfrY4jQSoZQWWygZ83roKXWD4YeT2x2p41dGkPixe73rT2IW04glagN2vgoZoHuOPqa5and6kAmK2ujmCHu6D1auJhE2tXP+yLkpSiYMQucDKmCsWMnW9XlC5K7OSL77TXXcfvTvyZcjObEz6LIBRzs6+FqpFbUO9SJEfh6wIDAQAB";
   // private static String privateKey = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAKAUZV+tjiNBKhlBZbKBnzeugpdYPhh5PbHanjV0aQ+LF7vetPYhbTiCVqA3a+Chmge44+prlqd3qQCYra6OYIe7oPVq4mETa1c/7IuSlKJgxC5wMqYKxYydb1eULkrs5IvvtNddx+9O/JlyM5sTPosgFHOzr4WqkVtQ71IkR+HrAgMBAAECgYAkQLo8kteP0GAyXAcmCAkA2Tql/8wASuTX9ITD4lsws/VqDKO64hMUKyBnJGX/91kkypCDNF5oCsdxZSJgV8owViYWZPnbvEcNqLtqgs7nj1UHuX9S5yYIPGN/mHL6OJJ7sosOd6rqdpg6JRRkAKUV+tmN/7Gh0+GFXM+ug6mgwQJBAO9/+CWpCAVoGxCA+YsTMb82fTOmGYMkZOAfQsvIV2v6DC8eJrSa+c0yCOTa3tirlCkhBfB08f8U2iEPS+Gu3bECQQCrG7O0gYmFL2RX1O+37ovyyHTbst4s4xbLW4jLzbSoimL235lCdIC+fllEEP96wPAiqo6dzmdH8KsGmVozsVRbAkB0ME8AZjp/9Pt8TDXD5LHzo8mlruUdnCBcIo5TMoRG2+3hRe1dHPonNCjgbdZCoyqjsWOiPfnQ2Brigvs7J4xhAkBGRiZUKC92x7QKbqXVgN9xYuq7oIanIM0nz/wq190uq0dh5Qtow7hshC/dSK3kmIEHe8z++tpoLWvQVgM538apAkBoSNfaTkDZhFavuiVl6L8cWCoDcJBItip8wKQhXwHp0O3HLg10OEd14M58ooNfpgt+8D8/8/2OOFaR0HzA+2Dm";
   private PrivateKey privateKey;
   private PublicKey publicKey;
   static final String KEY_ALGORITHM = "RSA";
   static final int KEY_LENGTH = 2048;

   public RSA() throws NoSuchAlgorithmException {
    KeyPairGenerator keyGen = KeyPairGenerator.getInstance(KEY_ALGORITHM);
    keyGen.initialize(KEY_LENGTH);
    KeyPair pair = keyGen.generateKeyPair();
    this.privateKey = pair.getPrivate();
    this.publicKey = pair.getPublic();
}

    private PublicKey getPublicKey(String base64PublicKey){
        PublicKey publicKey = null;
        try{
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64PublicKey.getBytes()));
            KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
            publicKey = keyFactory.generatePublic(keySpec);
            return publicKey;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
        return publicKey;
    }
    private PrivateKey getPrivateKey(String base64PrivateKey){
        PrivateKey privateKey = null;
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(base64PrivateKey.getBytes()));
        KeyFactory keyFactory = null;
        try {
            keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        try {
            privateKey = keyFactory.generatePrivate(keySpec);
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
        return privateKey;
    }

    private byte[] encrypt(String data, String publicKey)
    throws BadPaddingException,
    IllegalBlockSizeException, 
    InvalidKeyException, 
    NoSuchPaddingException,
    NoSuchAlgorithmException {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(publicKey));
        return cipher.doFinal(data.getBytes());
    }

    private String decrypt(byte[] data, PrivateKey privateKey) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        return new String(cipher.doFinal(data));
    }

    private String decrypt(String data, String base64PrivateKey) throws IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
        return decrypt(Base64.getDecoder().decode(data.getBytes()), getPrivateKey(base64PrivateKey));
    }
   
    private PrivateKey getPrivateKey() {
        return privateKey;
    }

    private PublicKey getPublicKey() {
        return publicKey;
    }

    public String Encryption(String key, String textPlain) {
     String   result="";
        try {
            result= Base64.getEncoder().encodeToString(encrypt(textPlain, key));
        } catch (InvalidKeyException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (BadPaddingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalBlockSizeException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return result;
    }
 
    public String Descryption(String key, String textPlain) {
        String   result="";
        try {
            result=decrypt(textPlain, key);
        } catch (InvalidKeyException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (BadPaddingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalBlockSizeException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return result;
    }
 
    public HashMap<String, String> Getkey()  {
        HashMap <String, String> map = new HashMap<String, String>();
      
        try {
            map.put("PublicKey",Base64.getEncoder().encodeToString(getPublicKey().getEncoded()));
            map.put("PrivateKey",Base64.getEncoder().encodeToString(getPrivateKey().getEncoded()));
            map.put("PublicKeyXml",GetPublicKeyFromBase64ToXML(getPublicKey()));
        } catch (NoSuchAlgorithmException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return map;
    }

    public String GetPublicKeyFromBase64ToXML(PublicKey publicKey) throws NoSuchAlgorithmException {
        String public_Xml ="";

        RSAPublicKey rSAPublicKey = (RSAPublicKey)publicKey;
        byte[] mod_Bytes_Extra =null;

        BigInteger mod_IntPublic = rSAPublicKey.getModulus();
        BigInteger exp_IntPublic = rSAPublicKey.getPublicExponent();


        mod_Bytes_Extra = mod_IntPublic.toByteArray();
        byte[] mod_Bytes = new byte[128];
        System.arraycopy(mod_Bytes_Extra, 1, mod_Bytes, 0, 128);


        byte[] exp_Bytes = exp_IntPublic.toByteArray();
        String modulus =Base64.getEncoder().encodeToString(mod_Bytes);
        String exponent = Base64.getEncoder().encodeToString(exp_Bytes);
        public_Xml = "<RSAKeyValue><Modulus>"+modulus+"</Modulus><Exponent>"+exponent+"</Exponent></RSAKeyValue>";
        
        return public_Xml;
    }
    public static void main(String[] args) throws NoSuchAlgorithmException{
        RSA crypto = new RSA();
        String privateKey ="MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCpBsKYIYUvm9PJUBfOC2CW/euDrdHC/7VkdR7dPCNVMB8Qrx6YOvVa4Luyl31GWkmxZJGtyNnNnERo/Itvcf1+taFzlPYpB4VkqE1Ya4M/pkiEs+aB8sYd80B5HkIwGs8kgHQZVJrYmGhqjilHXNDUo5/B/tX0ldIO0V5+bJofc7aku2KoiTHWuRuIJUFreAY1HPdfJPYE9YaILlaOb26xWnDdW6rWXmUve9lfOsjIwrIWHrAWHu49WMXkYz9kx/kj15nHIUOHxRwevXy0oiCwryPCIm2IYO8zmqJTKaXaxnwDExKlZZaEvjo24801rqZFAieDNKSXm8hPHrojxVOXAgMBAAECggEASNYZ6tae/voGVHzIFUj/0XEQGQlBF+d68hQqPamZjC8VY+oio/TcH9Ix7+6p1DQ6B1BQGnQvrxOEwzz4lQio9P4t2ZG6Vcng6JRB6DVENJxiKZUgYqUMTIGzKb4pRXN4CcG0xemYZHegnzIthYvwjYEI6d73sdMR1sLQFmiULbLJNrACPfdhCCgLU2KXpaIWGXzxYn0+7Wy+AEZMm7VGW31zOd6kT5OdK3O05IVMLtDWRkYLBk8wyxaqgktEuJQ9/vliZZoWsOs6cBo7pj6BkbjzHbxdAzqEgRFy3e+P17UwMcMZD9l9e5FUAgi/Sq7cPlrtvzTKOBIVN36/sXc54QKBgQDwmnWOVmO5mbDBFfe8wm1/H3m63XEauefUu/3dXkfphBf6riD/71CmZ5SBUujIia3H756YQbGijpmJWi94akdZRQH/WJtA6kh9rBcOMjkHdscdmL2DUH9+8N1RPQv1hQArx2SGPW//rfwctiiHbnTo2QGYd+44yo0px8GApzsuUQKBgQCz17v7J6UQ+dyMMvE3+ELZlBCDm3faSjtJane7rbi2CdOxI6eSJP6QXkpY0QsryKZCZ5U/aajL2QfCQW6JDtpzqMb/Fnjq/f3jqfd7jKSxRMLlXjOawCXA57zyF64oNw28cxevG1RLrDpPSu8X4QpzCK1erpK+PzeGuCIewJlhZwKBgQDLTLgoHTcGjKadgEJkbKS41Y+2JYZ8XrlVN8O6WP/KgKMCXj/kAgLTmJIS9Etdp3f/iKkpXdkK0hNJy7pwtNy0wWp+qBAHOe8mwVJ53FXzyJlWmMkJO+t/B2b6Terc+hS66TA3fZI1KH3uhLyaMur2FOcUPcI8mmnM88y9OJD5AQKBgFp4BBBr+RV5HAFK/x1wvfBGE6ig5MHi5cAg1uqKkYjBmMRbc0iJY6WsSSo0vrHf1gNBqEqmFEu3ebe2wqwf1LSqCrD31QwhiT6lmeGE9rRWKtTHdp46WsOXz+zZDLseNsK+AwQLc3Q9x3dr8qrIgkEr9ErU9uzNUFls930Q1hexAoGAL0JXzkTnADmONgGBog7lOXpE6azZLaOmpO+gU7V1OXFDFfGBboozVJgYV3fK4JqXZ+roNz0uN9YVfwDN0TARiYo2rJkXhMxALWcyf/HIOwQGIIYYaYre04yzR1GJNqr8xfsqPLlGn2yeaIslPYfTPsaFtdOuOqLL05V48XFAQeM=";
        String encrypted=  crypto.Encryption(crypto.Getkey().get("PublicKey"), "Hola mundo");
        String decripted=  crypto.Descryption(privateKey, "U4yDCmnNfnz5I4laWfgSSMiyDkiTPKDU+MfB4TNurXH10S1eYGYQcpCXwQfgzbkOR8OJi+FhLrsNFXBehN5ou9g7A8/i9NZQSD1zW8YGztyBhNrpNG1rcoJC6hDFgNMGCwC705gSeDhq7SscqWmhE5slRH/lIqiCXL4YCInVeJ05Dk0HaAZ+6q04Gkzv7KNWU27c6mRmWMrkJyaSaGjw7Vuajc9m2gZ30hzCBOwoMS3OoWd8FLEaNNbpTMVubrQt4CkoIcD+HEUh4PcmnMcE7j4009uSLYCpkHNOUHVxiNedvf6xLq00kFaTSwb3t4xKatT7uHkO+bEkqQvfdG927w==");
       // System.out.println(encrypted);
        System.out.println(decripted);
       // System.out.println(crypto.Getkey());

    }
}