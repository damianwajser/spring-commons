package com.github.damianwajser.crypto;

public enum CryptoFormat {
   RSA, 
   PBE,
   
    
}
